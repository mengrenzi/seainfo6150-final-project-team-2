import React from "react";
import PropTypes from "prop-types";
import {Link} from "react-router-dom";
import "./FloorPlanPage.css";

const FloorPlanPage = ({floor}) => {
  return (
    <div>
        123
    </div>
  );
};

FloorPlanPage.propTypes = {
  floor: PropTypes.array.isRequired,
};

export default FloorPlanPage;
